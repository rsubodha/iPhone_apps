//
//  iPayTributeAppDelegate.m
//  iPayTribute
//
//  Created by Raghuveer Subodha on 06/10/11.
//  Copyright __MyCompanyName__ 2011. All rights reserved.
//

#import "iPayTributeAppDelegate.h"
#import "iPayTributeViewController.h"

@implementation iPayTributeAppDelegate

@synthesize window;
@synthesize viewController;


- (void)applicationDidFinishLaunching:(UIApplication *)application {    
    
    // Override point for customization after app launch    
    [window addSubview:viewController.view];
    [window makeKeyAndVisible];
}


- (void)dealloc {
    [viewController release];
    [window release];
    [super dealloc];
}


@end
