//
//  imageXMLElement.m
//  iPayTribute
//
//  Created by Raghuveer Subodha on 23/10/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import "imageXMLElement.h"


@implementation imageXMLElement
@synthesize image;
@synthesize imageTitle;

@end
