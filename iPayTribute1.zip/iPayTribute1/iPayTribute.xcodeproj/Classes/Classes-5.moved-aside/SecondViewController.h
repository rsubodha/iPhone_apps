//
//  SecondViewController.h
//  iPayTribute
//
//  Created by Raghuveer Subodha on 08/10/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>


@interface SecondViewController : UITableViewController {

	IBOutlet UIScrollView *mscrollView1;
	
	
}

@property (nonatomic, retain) IBOutlet UIScrollView *mscrollView1;


@end
