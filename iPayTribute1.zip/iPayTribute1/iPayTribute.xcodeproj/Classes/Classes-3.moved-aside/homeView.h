//
//  homeView.h
//  PerfectValentine
//
//  Created by Meenakshi Subodha on 08/02/10.
//  Copyright 2010 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>


@interface homeView : UITableViewCell {

	IBOutlet UILabel *cellText;
	IBOutlet UIImageView *productImg;
	IBOutlet UILabel *descriptionText;
}

- (void)setLabelText:(NSString *)_text;
- (void)setDescpText:(NSString *)_text;
- (void)setProductImage:(NSString *)_text;

@end
