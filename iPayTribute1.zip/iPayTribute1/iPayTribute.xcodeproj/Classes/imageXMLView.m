//
//  imageXMLView.m
//  iPayTribute
//
//  Created by Raghuveer Subodha on 23/10/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import "imageXMLView.h"


@implementation imageXMLView

@synthesize imageTltle;
@synthesize imageView;

- (id)initWithFrame:(CGRect)frame {
    if (self = [super initWithFrame:frame]) {
        // Initialization code
    }
    return self;
}


- (void)drawRect:(CGRect)rect {
    // Drawing code
}


- (void)dealloc {
    [super dealloc];
}


@end
