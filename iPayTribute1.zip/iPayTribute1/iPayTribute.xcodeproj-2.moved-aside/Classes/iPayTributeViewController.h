//
//  iPayTributeViewController.h
//  iPayTribute
//
//  Created by Raghuveer Subodha on 07/10/11.
//  Copyright __MyCompanyName__ 2011. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface iPayTributeViewController : UIViewController {

}

@end

